import os, sys, requests
from subprocess import Popen
from colorama import Fore as color 
from time import sleep

bold = '\033[1m'
endbold = '\033[0m'

def banner():
    os.system('clear')
    print(color.RED+"""
██ ██████     ██████  ██   ██ ██ ███████ ██   ██ ███████ ██████  
██ ██   ██    ██   ██ ██   ██ ██ ██      ██   ██ ██      ██   ██ 
██ ██████     ██████  ███████ ██ ███████ ███████ █████   ██████  
██ ██   ██    ██      ██   ██ ██      ██ ██   ██ ██      ██   ██ 
██ ██   ██ ██ ██      ██   ██ ██ ███████ ██   ██ ███████ ██   ██ 
                                                                 """+color.WHITE+'version 1.0')
    print(bold +color.LIGHTWHITE_EX+"""    
┍━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┑ 
☫  Programmer: Mon3ter               ☫   
☫  Contact: sshprotokolzd@gmail.com  ☫                   
☫  YouTube: TheZeroDey               ☫
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
"""+endbold)
    sleep(0.1)


def menu_respaws():
    try:
        print(color.RED+"[1] "+ color.LIGHTYELLOW_EX+"INSTAGRAM")
        print(color.CYAN+"*********************")
        sleep(0.1)
        
        print(color.RED+"[0] "+ color.LIGHTYELLOW_EX+"Exit")
        print(color.CYAN+"*********************")
        sleep(0.1)
    except:
        print(color.RED+"[-] Something Went Wrong....")
        sleep(1)
        sys.exit()



